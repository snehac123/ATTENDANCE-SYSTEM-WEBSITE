
<?php
$conn = mysqli_connect("localhost:3307","root","","attendance_sys");

if(!$conn){
	die("Connection error: " . mysqli_connect_error());
}
?>
