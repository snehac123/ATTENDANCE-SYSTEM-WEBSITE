<?php
	$conn = new mysqli('localhost:3307', 'root', '','attendance_sys') or die("Database Connection Failed");
