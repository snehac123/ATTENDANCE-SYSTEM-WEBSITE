<?php
if(isset($_POST['name'])){
$hostName = "localhost";
$userName = "root";
$password = "";
$conn = mysqli_connect($hostName, $userName, $password, $databaseName);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . mysqli_connect_error());
}
echo "Success connecting to the db";
$name=$_POST['name'];
$breakin=$_POST['in'];
$breakout=$_POST['out'];

$sql="INSERT INTO `break` ( `Name`, `Break-in`, `Break-out`) VALUES ('$name', CURRENT_TIME(), CURRENT_TIME());";
if($con->query($sql) == true){
   echo "Successfully inserted";
 }

 else{
   echo "ERROR: $sql <br> $con->error";
 }

 $con->close();
}

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin page</title>
    <link rel="stylesheet" href="./admin.css" />
  </head>
  <body>
    <header class="header">
      <div class="brand">
        <a href="#" class="brand-logo">
          To be Honest
        </a>
        <div class="nav-burger" id="nav-burger">
          <img src="hamburger-button.png" alt="Menu">
        </div>
        <div class="nav-cancel is-active" id="nav-cancel">
          <img src="cancel-button.png" alt="Cancel">
        </div>
      </div>  
      
      <nav class="nav is-active" id="nav">
        
        <a href="#" class="nav-link">SignIn</a>
      </nav>
      
    </header>
    <div class="container">
      <div class="data">
        <ul>
          <li>Serial No.</li>
          <li>Name</li>
          <li>Shift</li>
          <li>Break</li>
        </ul>
      </div>
    </div>
    <script src="./navbar.js"></script>
  </body>
</html>
