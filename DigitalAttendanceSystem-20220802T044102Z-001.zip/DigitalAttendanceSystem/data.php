<?php
$hostName = "localhost";
$userName = "root";
$password = "";
 $conn = mysqli_connect($hostName, $userName, $password, $databaseName);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . mysqli_connect_error());
}
echo "Success connecting to the db";

$sql="INSERT INTO `break` (`s.no.`, `Name`, `Break-in`, `Break-out`) VALUES ('1', 'testName', CURRENT_TIME(), CURRENT_TIME());"
?>